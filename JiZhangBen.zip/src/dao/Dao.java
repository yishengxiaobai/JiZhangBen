package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import entity.Account;
import util.Shujuku;

public class Dao {
	public boolean rename(String name) {
		// ���������Ƿ��ظ�
		boolean f=false;
		String sql="select name from account where name='"+name+"'";//���ݿ���䣬��ѯ��������ͱ���name�Ƿ��ظ�
		Connection conn = Shujuku.conn();//��������
		Statement state = null;//����Statement����ִ�о�̬SQL���
		ResultSet rs = null;//ResultSet���� �ǲ�ѯ���ݿ�ʱ�ķ��ض��󣬶�ȡ���ؽ����
		
		try {
			state = conn.createStatement();
			rs = state.executeQuery(sql);
			while (rs.next()) {//���ظ�������true
				f = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			Shujuku.close(rs, state, conn);
		}
		return f;
	}

	public boolean add(Account account) {
		//����
		String sql = "insert into account(name,amount,money,time) values('" +account.getName() + "','" + account.getAmount() + "','" + account.getMoney() + "','" +account.getTime() + "')";//����
		Connection conn = Shujuku.conn();
		Statement state = null;
		boolean f = false;
		int a=0;
		try {
			state = conn.createStatement();
			a=state.executeUpdate(sql);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Shujuku.close(state, conn);
		}
		if (a > 0) {
			f = true;
		}
		return f;
	}

	
	public boolean delete(String name) {
		// ͨ������ɾ��
		boolean f=false;
		String sql = "delete from account where name ='" + name + "'";//ɾ��
		Connection conn = Shujuku.conn();
		Statement state = null;
		int a=0;
		try {
			state = conn.createStatement();
			a=state.executeUpdate(sql);
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			Shujuku.close(state, conn);
		}
		if(a>0) {
			f=true;
		}
		return f;
	}
	public boolean update(Account account) {
		// �޸�
		String sql = "update account set amount='" + account.getAmount() + "', money='" + account.getMoney()+"',time='" + account.getTime()+"'where name='"+account.getName()+"'";
		Connection conn = Shujuku.conn();
		Statement state = null;
		boolean f = false;
		int a = 0;

		try {
			state = conn.createStatement();
			a = state.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			Shujuku.close(state, conn);
		}
	
		if (a > 0) {
			f = true;
		}
		return f;
		
	}
	public List<Account> show(String name) {
		// �г�����
		String sql = "select * from account";
		Connection conn = Shujuku.conn();
		Statement state = null;
		ResultSet rs = null;
		List<Account> list = new ArrayList<>();
		try {
			state = conn.createStatement();
			rs = state.executeQuery(sql);
			Account bean = null;
			while (rs.next()) {
				
				String a = rs.getString("name");
				String b = rs.getString("amount");
				String c= rs.getString("money");
				String d= rs.getString("time");
				 bean= new Account( a,b,c,d);
				 list.add(bean);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			Shujuku.close(rs, state, conn);
		}
		
		return list;
	}
	
	public Account getByname(String name) {
		//ͨ�����ֵõ�
		//ģ����ѯ
		String sql = "select * from account where ";
		if (name != "") {
			sql += "name like '%" + name + "%'";
		}
		Connection conn = Shujuku.conn();
		Statement state = null;
		ResultSet rs = null;
		Account account = null;
		try {
			state = conn.createStatement();
			rs = state.executeQuery(sql);
			while (rs.next()) {
				String d=rs.getString("name");
				String a = rs.getString("amount");
				String b=rs.getString("money");
				String c=rs.getString("time");
				account = new Account(d,a,b,c);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Shujuku.close(rs, state, conn);
		}
		
		return account;
	}

	public List<Account> list() {
		String sql = "select * from account";
		List<Account> list = new ArrayList<>();
		Connection conn = Shujuku.conn();
		Statement state = null;
		ResultSet rs = null;

		try {
			state = conn.createStatement();
			rs = state.executeQuery(sql);
			Account bean = null;
			while (rs.next()) {
				
				String a = rs.getString("name");
				String b = rs.getString("amount");
				String c = rs.getString("money");
				String d = rs.getString("time");
				bean = new Account(a,b,c,d);
				list.add(bean);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			Shujuku.close(rs, state, conn);
		}
		
		return list;
	}

	public Account getByname2(String name) {
		String sql = "select * from account where ";
		if (name != "") {
			sql += "name like '%" + name + "%'";
		}
		Connection conn = Shujuku.conn();
		Statement state = null;
		ResultSet rs = null;
		Account account = null;
		try {
			state = conn.createStatement();
			rs = state.executeQuery(sql);
			while (rs.next()) {
				String d=rs.getString("name");
				String a = rs.getString("amount");
				String b=rs.getString("money");
				String c=rs.getString("time");
				account = new Account(d,a,b,c);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Shujuku.close(rs, state, conn);
		}
		
		return account;
	}
}
