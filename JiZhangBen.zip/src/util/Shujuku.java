package util;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Shujuku {
	 public static Connection conn(){
		 String url="jdbc:sqlserver://localhost:1433;DatabaseName=Jizhangben";//��д������ݿ���
	     String userName="sa";//��д����û������ҵ���sa
	     String userPwd="tzk19991029";//��д�������tzk19991029
         Connection connection=null;

  try{
      Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
      System.out.println("���������ɹ���");

  }catch(Exception e){

	       e.printStackTrace();

	       System.out.println("��������ʧ�ܣ�");
   }
 try{
	connection=DriverManager.getConnection(url,userName,userPwd);
 System.out.println("�������ݿ�ɹ���");
 }catch(Exception e){
        e.printStackTrace();
        System.out.print("SQL Server����ʧ�ܣ�");
  }	
 return connection;
}
public static void close (Statement state, Connection conn) {//�ر�
	if (state != null) {
		try {
			state.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	if (conn != null) {
		try {
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}

public static void close (ResultSet rs, Statement state, Connection conn) {//�ر�
	if (rs != null) {
		try {
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	if (state != null) {
		try {
			state.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	if (conn != null) {
		try {
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}

}